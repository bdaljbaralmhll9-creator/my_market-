import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

enum Stage { loading, needLink, needSetup, needLogin, ready, error }

class AppState extends ChangeNotifier {
  Stage stage = Stage.loading;
  AppUser? me;
  String storeName = '';
  String currency = '';
  String errorText = '';

  FirebaseFirestore get db => FirebaseFirestore.instance;

  // ---------- البداية ----------
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('fb_config');
    if (raw == null) {
      stage = Stage.needLink;
      notifyListeners();
      return;
    }
    try {
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(options: _options(raw));
      }
      await _afterLink();
    } catch (e) {
      _fail(e);
    }
  }

  Future<void> retry() async {
    stage = Stage.loading;
    notifyListeners();
    try {
      if (Firebase.apps.isEmpty) {
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString('fb_config');
        if (raw == null) {
          stage = Stage.needLink;
          notifyListeners();
          return;
        }
        await Firebase.initializeApp(options: _options(raw));
      }
      await _afterLink();
    } catch (e) {
      _fail(e);
    }
  }

  void _fail(Object e) {
    errorText = _err(e);
    stage = Stage.error;
    notifyListeners();
  }

  FirebaseOptions _options(String raw) {
    final m = jsonDecode(raw) as Map<String, dynamic>;
    for (final k in ['apiKey', 'appId', 'projectId']) {
      if (m[k] == null || (m[k] as String).isEmpty) {
        throw FormatException('الحقل $k ناقص');
      }
    }
    return FirebaseOptions(
      apiKey: m['apiKey'] as String,
      appId: m['appId'] as String,
      messagingSenderId: (m['messagingSenderId'] ?? '') as String,
      projectId: m['projectId'] as String,
      storageBucket: m['storageBucket'] as String?,
    );
  }

  // ---------- ربط المتجر ----------
  Future<String?> link(String raw) async {
    try {
      final options = _options(raw.trim());
      if (Firebase.apps.isEmpty) {
        await Firebase.initializeApp(options: options);
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('fb_config', raw.trim());
      await _afterLink();
      return null;
    } on FormatException catch (e) {
      return 'بيانات الربط غير صحيحة: ${e.message}';
    } catch (e) {
      _fail(e);
      return null;
    }
  }

  Future<void> _afterLink() async {
    final info = await db.collection('store').doc('info').get();
    if (!info.exists) {
      stage = Stage.needSetup;
      notifyListeners();
      return;
    }
    storeName = (info.data()?['name'] ?? '') as String;
    currency = (info.data()?['currency'] ?? '') as String;
    final u = FirebaseAuth.instance.currentUser;
    if (u != null && await _loadMe(u.uid)) {
      stage = Stage.ready;
    } else {
      stage = Stage.needLogin;
    }
    notifyListeners();
  }

  Future<bool> _loadMe(String uid) async {
    final d = await db.collection('users').doc(uid).get();
    if (!d.exists) return false;
    final u = AppUser.fromDoc(d);
    if (!u.active) return false;
    me = u;
    return true;
  }

  // ---------- الإعداد الأول (المدير) ----------
  Future<String?> setupStore({
    required String storeName,
    required String phone,
    required String currency,
    required String ownerName,
    required String username,
    required String password,
  }) async {
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _email(username),
        password: password,
      );
      final uid = cred.user!.uid;
      await db.collection('users').doc(uid).set({
        'name': ownerName,
        'username': username.toLowerCase(),
        'role': Roles.owner,
        'active': true,
        'permissions': {for (final p in Perm.all) p: true},
        'createdAt': FieldValue.serverTimestamp(),
      });
      await db.collection('store').doc('info').set({
        'name': storeName,
        'phone': phone,
        'currency': currency,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await _afterLink();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  // ---------- تسجيل الدخول والخروج ----------
  Future<String?> login(String username, String password) async {
    try {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email(username),
        password: password,
      );
      if (!await _loadMe(cred.user!.uid)) {
        await FirebaseAuth.instance.signOut();
        return 'هذا الحساب غير مفعّل أو غير موجود';
      }
      stage = Stage.ready;
      notifyListeners();
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
    me = null;
    stage = Stage.needLogin;
    notifyListeners();
  }

  // ---------- إدارة الموظفين (المدير فقط) ----------
  Future<String?> createEmployee({
    required String name,
    required String username,
    required String password,
    required String role,
    required Map<String, bool> permissions,
  }) async {
    FirebaseApp? secondary;
    try {
      // نستخدم تطبيقاً ثانوياً حتى لا يخرج المدير من حسابه عند إنشاء الموظف
      secondary = await Firebase.initializeApp(
        name: 'secondary',
        options: Firebase.app().options,
      );
      final auth = FirebaseAuth.instanceFor(app: secondary);
      final cred = await auth.createUserWithEmailAndPassword(
        email: _email(username),
        password: password,
      );
      await db.collection('users').doc(cred.user!.uid).set({
        'name': name,
        'username': username.toLowerCase(),
        'role': role,
        'active': true,
        'permissions': permissions,
        'createdAt': FieldValue.serverTimestamp(),
      });
      await auth.signOut();
      return null;
    } catch (e) {
      return _err(e);
    } finally {
      await secondary?.delete();
    }
  }

  Future<String?> updateUser(String uid, Map<String, dynamic> data) async {
    try {
      await db.collection('users').doc(uid).update(data);
      return null;
    } catch (e) {
      return _err(e);
    }
  }

  // ---------- مساعدات ----------
  String _email(String username) => '${username.trim().toLowerCase()}@store.local';

  String _err(Object e) {
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'email-already-in-use':
          return 'اسم المستخدم مستخدم من قبل';
        case 'weak-password':
          return 'كلمة المرور ضعيفة (6 أحرف على الأقل)';
        case 'invalid-credential':
        case 'wrong-password':
        case 'user-not-found':
        case 'invalid-email':
          return 'اسم المستخدم أو كلمة المرور غير صحيحة';
        case 'network-request-failed':
          return 'لا يوجد اتصال بالإنترنت';
        case 'operation-not-allowed':
          return 'فعّل تسجيل الدخول بالبريد وكلمة المرور من لوحة Firebase';
      }
    }
    if (e is FirebaseException) {
      if (e.code == 'permission-denied') return 'ليست لديك صلاحية لهذه العملية';
      if (e.code == 'unavailable') return 'لا يوجد اتصال، وهذه البيانات غير محفوظة على الجهاز بعد';
    }
    return 'حدث خطأ: $e';
  }
}
