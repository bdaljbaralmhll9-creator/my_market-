import 'package:cloud_firestore/cloud_firestore.dart';

class Perm {
  static const sell = 'sell';
  static const changePrice = 'changePrice';
  static const manageProducts = 'manageProducts';
  static const discount = 'discount';
  static const credit = 'credit';
  static const deleteInvoice = 'deleteInvoice';
  static const viewProfit = 'viewProfit';
  static const reports = 'reports';

  static const all = [
    sell, changePrice, manageProducts, discount,
    credit, deleteInvoice, viewProfit, reports,
  ];

  static const labels = <String, String>{
    sell: 'البيع وإصدار الفواتير',
    changePrice: 'تغيير الأسعار',
    manageProducts: 'إضافة وتعديل المنتجات',
    discount: 'إعطاء خصم',
    credit: 'البيع بالدين وتسجيل السداد',
    deleteInvoice: 'حذف أو إلغاء الفواتير',
    viewProfit: 'رؤية الأرباح وأسعار الشراء',
    reports: 'التقارير',
  };
}

class Roles {
  static const owner = 'owner';
  static const accountant = 'accountant';
  static const cashier = 'cashier';
  static const storekeeper = 'storekeeper';

  static const employeeRoles = [cashier, accountant, storekeeper];

  static const labels = <String, String>{
    owner: 'المدير',
    accountant: 'محاسب',
    cashier: 'كاشير',
    storekeeper: 'أمين مخزن',
  };

  /// الصلاحيات الافتراضية لكل دور (يستطيع المدير تعديلها بعد ذلك)
  static Map<String, bool> defaults(String role) {
    final m = {for (final p in Perm.all) p: false};
    switch (role) {
      case cashier:
        m[Perm.sell] = true;
        break;
      case accountant:
        m[Perm.sell] = true;
        m[Perm.credit] = true;
        m[Perm.reports] = true;
        break;
      case storekeeper:
        m[Perm.manageProducts] = true;
        break;
    }
    return m;
  }
}

class AppUser {
  final String uid;
  final String name;
  final String username;
  final String role;
  final bool active;
  final Map<String, bool> permissions;

  AppUser({
    required this.uid,
    required this.name,
    required this.username,
    required this.role,
    required this.active,
    required this.permissions,
  });

  bool get isOwner => role == Roles.owner;

  bool can(String p) => active && (isOwner || (permissions[p] ?? false));

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    final raw = (m['permissions'] ?? {}) as Map;
    return AppUser(
      uid: d.id,
      name: (m['name'] ?? '') as String,
      username: (m['username'] ?? '') as String,
      role: (m['role'] ?? Roles.cashier) as String,
      active: (m['active'] ?? true) as bool,
      permissions: {for (final e in raw.entries) e.key as String: e.value == true},
    );
  }
}
