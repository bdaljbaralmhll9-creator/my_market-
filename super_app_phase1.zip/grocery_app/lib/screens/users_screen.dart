import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('المستخدمون والصلاحيات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () =>
            showDialog(context: context, builder: (_) => const UserDialog()),
        icon: const Icon(Icons.person_add_rounded),
        label: const Text('موظف جديد'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: s.db.collection('users').snapshots(),
        builder: (context, snap) {
          if (snap.hasError) return const Center(child: Text('تعذر تحميل المستخدمين'));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final users = snap.data!.docs.map(AppUser.fromDoc).toList();
          return ListView.separated(
            padding: const EdgeInsets.only(bottom: 90),
            itemCount: users.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final u = users[i];
              return ListTile(
                leading: CircleAvatar(
                  child: Icon(u.isOwner
                      ? Icons.shield_rounded
                      : u.role == Roles.cashier
                          ? Icons.point_of_sale_rounded
                          : u.role == Roles.accountant
                              ? Icons.calculate_rounded
                              : Icons.inventory_2_rounded),
                ),
                title: Text(u.name),
                subtitle: Text('${Roles.labels[u.role] ?? u.role}  •  ${u.username}'),
                trailing: u.isOwner
                    ? null
                    : Switch(
                        value: u.active,
                        onChanged: (v) => s.updateUser(u.uid, {'active': v}),
                      ),
                onTap: u.isOwner
                    ? null
                    : () => showDialog(
                        context: context, builder: (_) => UserDialog(user: u)),
              );
            },
          );
        },
      ),
    );
  }
}

class UserDialog extends StatefulWidget {
  final AppUser? user;
  const UserDialog({super.key, this.user});

  @override
  State<UserDialog> createState() => _UserDialogState();
}

class _UserDialogState extends State<UserDialog> {
  final _name = TextEditingController();
  final _username = TextEditingController();
  final _password = TextEditingController();
  String _role = Roles.cashier;
  Map<String, bool> _perms = Roles.defaults(Roles.cashier);
  bool _busy = false;
  String? _error;

  bool get _isNew => widget.user == null;

  @override
  void initState() {
    super.initState();
    final u = widget.user;
    if (u != null) {
      _name.text = u.name;
      _username.text = u.username;
      _role = u.role;
      _perms = {for (final p in Perm.all) p: u.permissions[p] ?? false};
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      setState(() => _error = 'أدخل اسم الموظف');
      return;
    }
    if (_isNew) {
      if (!RegExp(r'^[a-zA-Z0-9._]{3,}$').hasMatch(_username.text.trim())) {
        setState(() => _error = 'اسم المستخدم: حروف إنجليزية وأرقام (3 أحرف على الأقل)');
        return;
      }
      if (_password.text.length < 6) {
        setState(() => _error = 'كلمة المرور 6 أحرف على الأقل');
        return;
      }
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final s = context.read<AppState>();
    final err = _isNew
        ? await s.createEmployee(
            name: _name.text.trim(),
            username: _username.text.trim(),
            password: _password.text,
            role: _role,
            permissions: _perms,
          )
        : await s.updateUser(widget.user!.uid, {
            'name': _name.text.trim(),
            'role': _role,
            'permissions': _perms,
          });
    if (!mounted) return;
    if (err == null) {
      Navigator.pop(context);
    } else {
      setState(() {
        _busy = false;
        _error = err;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(_isNew ? 'موظف جديد' : 'تعديل الموظف'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'الاسم'),
              ),
              if (_isNew) ...[
                TextField(
                  controller: _username,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(labelText: 'اسم المستخدم'),
                ),
                TextField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'كلمة المرور'),
                ),
              ],
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _role,
                decoration: const InputDecoration(labelText: 'الدور'),
                items: [
                  for (final r in Roles.employeeRoles)
                    DropdownMenuItem(value: r, child: Text(Roles.labels[r]!)),
                ],
                onChanged: (v) => setState(() {
                  _role = v!;
                  _perms = Roles.defaults(v);
                }),
              ),
              const SizedBox(height: 12),
              Text('الصلاحيات', style: Theme.of(context).textTheme.titleSmall),
              for (final p in Perm.all)
                SwitchListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(Perm.labels[p]!),
                  value: _perms[p] ?? false,
                  onChanged: (v) => setState(() => _perms[p] = v),
                ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!,
                      style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _busy ? null : _save,
          child: Text(_isNew ? 'إنشاء' : 'حفظ'),
        ),
      ],
    );
  }
}
