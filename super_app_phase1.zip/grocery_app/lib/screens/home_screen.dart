import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../models.dart';
import 'users_screen.dart';

class _Module {
  final String title;
  final IconData icon;
  final bool Function(AppUser) allowed;
  final Widget? page;
  const _Module(this.title, this.icon, this.allowed, [this.page]);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final me = s.me!;
    final modules = <_Module>[
      _Module('البيع', Icons.point_of_sale_rounded, (u) => u.can(Perm.sell)),
      _Module('المنتجات', Icons.inventory_2_rounded, (u) => u.can(Perm.manageProducts)),
      _Module('الباركود', Icons.qr_code_2_rounded, (u) => u.can(Perm.manageProducts)),
      _Module('الديون', Icons.account_balance_wallet_rounded, (u) => u.can(Perm.credit)),
      _Module('التقارير', Icons.bar_chart_rounded, (u) => u.can(Perm.reports)),
      _Module('المستخدمون والصلاحيات', Icons.admin_panel_settings_rounded,
          (u) => u.isOwner, const UsersScreen()),
    ].where((m) => m.allowed(me)).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(s.storeName),
        actions: [
          IconButton(
            tooltip: 'خروج',
            onPressed: () => s.logout(),
            icon: const Icon(Icons.logout_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: CircleAvatar(child: Text(me.name.isEmpty ? '?' : me.name[0])),
              title: Text(me.name),
              subtitle: Text(Roles.labels[me.role] ?? me.role),
            ),
          ),
          const SizedBox(height: 16),
          if (modules.isEmpty)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Text('لا توجد صلاحيات لهذا الحساب. اطلب من المدير تفعيلها.',
                  textAlign: TextAlign.center),
            )
          else
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.15,
              children: [
                for (final m in modules)
                  Card(
                    clipBehavior: Clip.antiAlias,
                    child: InkWell(
                      onTap: () {
                        if (m.page != null) {
                          Navigator.push(
                              context, MaterialPageRoute(builder: (_) => m.page!));
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('هذه الشاشة في المرحلة القادمة')),
                          );
                        }
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(m.icon,
                              size: 40, color: Theme.of(context).colorScheme.primary),
                          const SizedBox(height: 8),
                          Text(m.title, textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
        ],
      ),
    );
  }
}
