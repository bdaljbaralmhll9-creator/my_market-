# تطبيق البقالة - المرحلة 1

## تشغيل المشروع
1. flutter create --org com.mystore --project-name grocery_app grocery_app
2. انسخ مجلد lib من هذا المشروع فوق lib في المشروع الجديد
3. من داخل المشروع:
   flutter pub add firebase_core firebase_auth cloud_firestore shared_preferences provider mobile_scanner
4. في android/app/build.gradle(.kts) اجعل minSdk = 23
5. flutter run

## تجهيز Firebase لكل متجر (مرة واحدة)
1. console.firebase.google.com ثم أنشئ مشروعاً باسم المتجر
2. Authentication > Sign-in method > فعّل Email/Password
3. Firestore Database > Create database (وضع Production)
4. Firestore > Rules > الصق محتوى firestore.rules ثم Publish
5. Project settings > أضف تطبيق Android (أي package name)، وخذ القيم: apiKey, appId, projectId, messagingSenderId
6. جهّز بيانات الربط بصيغة JSON:
   {"apiKey":"...","appId":"...","projectId":"...","messagingSenderId":"..."}
7. الصق النص في شاشة الربط، أو حوّله إلى QR (أي موقع إنشاء QR) وامسحه من الأجهزة الأخرى
